package kgu.kgu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KguApplicationTests {

	@Test
	void contextLoads() {
	}

}
