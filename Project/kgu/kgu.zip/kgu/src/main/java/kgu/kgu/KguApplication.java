package kgu.kgu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KguApplication {

	public static void main(String[] args) {
		SpringApplication.run(KguApplication.class, args);
	}

}
