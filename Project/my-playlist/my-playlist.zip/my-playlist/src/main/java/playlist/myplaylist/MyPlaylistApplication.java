package playlist.myplaylist;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyPlaylistApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyPlaylistApplication.class, args);
	}

}
